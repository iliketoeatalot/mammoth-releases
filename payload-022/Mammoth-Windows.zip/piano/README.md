# Mammoth upright piano

21 recordings from VSCO 2 Community Edition, Upright Nr1.
Recorded by Sam Gossner and Simon Dalzell; sample cutting by Elan Hickler / Soundemote.
Source: https://github.com/sgossner/VSCO-2-CE
Publisher: https://versilian-studios.com/vsco-community/
Licence: CC0-1.0 (included). Commercial redistribution is permitted.

Converted for Mammoth to mono 22,050 Hz PCM16, leading silence removed,
tails capped at eight seconds with a short end fade. Three dynamic layers,
seven pitch zones; intervening pitches are resampled. This compact upright
is not a concert-grand library, and does not yet model sympathetic resonance.
Original source blob IDs and converted SHA-256 values are in manifest.json.
All samples load at startup; audio callbacks never read disk.

No new runtime dependency. PCM decoding/resampling uses Mammoth's bounded
sampler on Windows and can be reused on iOS. These are static audio assets,
not an external service or plugin requiring continued availability.
