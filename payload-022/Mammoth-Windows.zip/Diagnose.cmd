@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Diagnose-Startup.ps1"
if errorlevel 1 (
  echo.
  echo The diagnostic launcher could not finish. Send a screenshot of this window.
)
pause
