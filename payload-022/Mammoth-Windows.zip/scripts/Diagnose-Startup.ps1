# Launch diagnostics. No registry edits, uploads, elevation or data resets.
# Mammoth itself performs its normal session recording while running.
$ErrorActionPreference = 'Stop'
$package = Split-Path $PSScriptRoot -Parent
$exe = Join-Path $package 'Mammoth.exe'
$lines = New-Object 'System.Collections.Generic.List[string]'
$started = Get-Date
$lines.Add('Mammoth Windows startup diagnostic v1')
$lines.Add('Collected: ' + $started.ToString('o'))
$lines.Add('OS: ' + [Environment]::OSVersion.VersionString)
$lines.Add('64-bit OS: ' + [Environment]::Is64BitOperatingSystem)
$lines.Add('64-bit launcher: ' + [Environment]::Is64BitProcess)
$lines.Add('Runtime: ' + [Environment]::Version.ToString())
$lines.Add('')
Write-Host 'Starting Mammoth and collecting its startup result...'
Write-Host 'This usually takes about 20 seconds. Existing settings and history will not be deleted or reset.'
try {
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Mammoth.exe is missing. Extract the complete ZIP first.' }
    $lines.Add('EXE SHA256: ' + (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash)
    $lines.Add('EXE bytes: ' + (Get-Item -LiteralPath $exe).Length)
    $prior = @(Get-Process -Name Mammoth -ErrorAction SilentlyContinue)
    $lines.Add('Mammoth processes already running: ' + $prior.Count)
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo.FileName = $exe
    $process.StartInfo.WorkingDirectory = $package
    $process.StartInfo.UseShellExecute = $false
    if (-not $process.Start()) { throw 'Windows did not create the process.' }
    $lines.Add('Started PID: ' + $process.Id)
    if ($process.WaitForExit(15000)) {
        $code = $process.ExitCode
        $hex = [BitConverter]::ToUInt32([BitConverter]::GetBytes([int]$code), 0)
        $lines.Add('Exit code decimal: ' + $code)
        $lines.Add(('Exit code hex: 0x{0:X8}' -f $hex))
        $lines.Add('Lifetime seconds: ' + [Math]::Round(((Get-Date) - $started).TotalSeconds, 2))
    } else {
        $process.Refresh()
        $lines.Add('Still running after 15 seconds; diagnostic launcher did not terminate it.')
        $lines.Add('Window handle present: ' + ($process.MainWindowHandle -ne [IntPtr]::Zero))
    }
} catch {
    $lines.Add('Launch diagnostic error: ' + $_.Exception.GetType().FullName)
    $lines.Add('Error HResult: ' + $_.Exception.HResult)
    # Avoid usernames and local paths in exception text.
    if (-not (Test-Path -LiteralPath $exe)) { $lines.Add('Mammoth.exe missing from extracted package.') }
}
$lines.Add('')
$lines.Add('Windows crash records for Mammoth only:')
$found = $false
for ($attempt = 0; $attempt -lt 8; $attempt++) {
    try {
        $events = @(Get-WinEvent -FilterHashtable @{LogName='Application'; Id=1000; StartTime=$started.AddMinutes(-2)} -MaxEvents 100 -ErrorAction SilentlyContinue)
        foreach ($event in $events) {
            [xml]$xml = $event.ToXml()
            $fields = @{}
            foreach ($item in $xml.Event.EventData.Data) { $fields[[string]$item.Name] = [string]$item.InnerText }
            $app = $fields['AppName']
            if (-not $app -and $event.Properties.Count -gt 0) { $app = [string]$event.Properties[0].Value }
            if ([IO.Path]::GetFileName($app) -ine 'Mammoth.exe') { continue }
            $found = $true
            $lines.Add('Crash record at: ' + $event.TimeCreated.ToString('o'))
            foreach ($name in @('AppName','AppVersion','ModuleName','ModuleVersion','ExceptionCode','FaultingOffset')) {
                if ($fields.ContainsKey($name)) { $lines.Add($name + ': ' + $fields[$name]) }
            }
            if (-not $fields.ContainsKey('ExceptionCode') -and $event.Properties.Count -ge 8) {
                foreach ($pair in @(@('AppName',0),@('AppVersion',1),@('ModuleName',3),@('ModuleVersion',4),@('ExceptionCode',6),@('FaultingOffset',7))) {
                    $lines.Add(([string]$pair[0]) + ': ' + [string]$event.Properties[[int]$pair[1]].Value)
                }
            }
        }
    } catch { $lines.Add('Windows crash log unavailable to this user. Exit result above remains useful.'); break }
    if ($found) { break }
    Start-Sleep -Milliseconds 750
}
if (-not $found) { $lines.Add('No matching Application Error record available. This does not mean the launch succeeded.') }
$lines.Add('')
$lines.Add('No MIDI notes, song names, personal files or unrelated Windows events collected.')
$reportName = 'Mammoth-Startup-Report-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt'
$report = Join-Path $package $reportName
try { [IO.File]::WriteAllLines($report, $lines, [Text.Encoding]::UTF8) }
catch {
    $report = Join-Path ([IO.Path]::GetTempPath()) $reportName
    [IO.File]::WriteAllLines($report, $lines, [Text.Encoding]::UTF8)
}
Write-Host ''
Write-Host 'Report ready. Attach the selected text file in the Mammoth chat.' -ForegroundColor Green
Write-Host 'You do not need to read or interpret it.'
Write-Host $report
Start-Process explorer.exe -ArgumentList ('/select,"' + $report + '"')
