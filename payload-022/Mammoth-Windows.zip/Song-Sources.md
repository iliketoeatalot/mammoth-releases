# Included scores and licensed adaptations

## minuet-g.mid
Minuet in G, BWV Anh.114. Christian Petzold (historically attributed to J. S. Bach). Edition maintained by Allen Garvin; Mutopia-2017/01/19-75.

Source: https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=75
Licence stated by Mutopia: Public Domain. Retrieved 2026-09-28.
SHA-256: fd87a6673e18104047842a1c858d2c9d8eb9ad845d7a8fa46e3664b17642cb75

## fur-elise.mid
Für Elise, WoO 59. Ludwig van Beethoven. Edition maintained by Stelios Samelis; Breitkopf & Härtel 1888; Mutopia-2015/08/18-931.

Source: https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=931
Licence stated by Mutopia: Public Domain. Retrieved 2026-09-28.
SHA-256: 1c12c21c7bbf4cf163896732672648a69d497636059837abd153c71abe50215a

Original MIDI bytes are retained here and embedded in BundledSongs.h. Source staff tracks determine the hands. Full timing is retained; Beginner removes the lower staff, Intermediate restores sparse lower-staff notes. These are practice variants, not independently authored beginner arrangements.

## monkeys-spinning-monkeys-piano.mid

"Monkeys Spinning Monkeys" Kevin MacLeod (incompetech.com)
Licensed under Creative Commons: By Attribution 4.0 License
https://creativecommons.org/licenses/by/4.0/

Composition copyright Kevin MacLeod, 2014. No endorsement is implied.

Track and current license: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1400011
Original composer-hosted score and parts: https://incompetech.com/music/royalty-free/sheetmusic/MSM%20Sheet%20Music.zip
Composer's licensing and adaptation FAQ: https://incompetech.com/music/royalty-free/faq.html
Retrieved and checked 2026-10-01.

Changes for Mammoth: a newly encoded piano practice adaptation of the original composition, using the complete 75-measure Flute 1 melody one octave below the source's sounded 8va-clef pitch. The cello part is reduced to one bass tone per measure, octave doubles and other voices are omitted, and the bass rhythm is replaced with a sustained tone. The tempo is 104 BPM, within the composer's stated 104-184+ BPM performance range. Melody onset rhythms are retained; MIDI note releases are shortened to 80% of their notated values for detached playing. The piece plays one complete pass and stops at the original repeat, without an invented ending. This adaptation is distributed under CC BY 4.0.

This is not the original audio recording, nor a third-party MIDI or piano arrangement. The flutetunes.com arrangement and the later Kaesi Green piano transcription were not used in the delivered MIDI.

75 measures, 300 beats, 336 melody notes and 75 simple bass notes. MIDI timeline: 173.0769 seconds at 104 BPM. The original 144 BPM tempo produces 125 seconds, matching the composer's published recording duration. Three MIDI tracks: conductor, right-hand melody, left-hand bass. Beginner practice preserves all melody notes and removes the bass; it is a practice variant of this arrangement. Chromatic notes and eighth-note runs remain, so start slowly.

SHA-256: 70312aa46498849826323ad2dad819a9970bd55178e8883abe5dc131c7dd750e
# 0.1.14 repertoire additions

Frère Jacques and London Bridge: traditional public-domain melodies, independently encoded in C with original simple Mammoth bass parts; two complete passes.

Amazing Grace: traditional NEW BRITAIN melody (Southern Harmony, 1835), independently encoded in C with original simple accompaniment. Reference: Brian Ammon's CC0 transcription, https://commons.wikimedia.org/wiki/File:AmazingGrace.svg (checked 2026-10-04). Two complete passes; no third-party recording.

Auld Lang Syne: traditional Scottish melody; original Mammoth accompaniment and beginner rhythm variant, complete verse/chorus twice. Historical melodic reference: Felix Horetzky / Boije #268 / Stan Sanderson, public-domain Mutopia edition: https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=1121 (checked 2026-10-04).

These four new Beginner arrangements retain every melody note. Existing catalog identities, arrangements and completion records remain unchanged.

## The Long Way Home

Mammoth original composition, 2026. 72 bars at 88 BPM, approximately 3:18.
Six marked sections, developed melody and broken-chord accompaniment. No third-party MIDI.

# 0.1.22 repertoire

The Entertainer (1902), Scott Joplin; Chris Sawer / Mutopia-2016/11/25-263. Public Domain. https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=263

Maple Leaf Rag (1899), Scott Joplin; Chris Sawer / Mutopia-2011/11/13-23. Public Domain. https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=23

Retrieved 2026-10-07. Exact source MIDI and LilyPond editions retained. MIDI conductor track 0, authored upper staff track 1/right hand, lower staff track 2/left hand. Cross-staff notation is retained by the source MIDI; no pitch threshold is used. The complete scores include original repeats, rhythms and velocities.

entertainer.mid SHA256: 33e4e81ee64ffb2edf90d1c6a1ddee7276507296bfb915c2bb775231a467f066

maple.mid SHA256: 3dd712a85fabd267f5a2cee5cb23af4683408c2f29b8814721844498f1ee4f66

Original Mammoth compositions are hidden from Library discovery, while their identities and history remain loadable.
