# Mammoth third-party notices

This package uses JUCE 9.0.2, pinned at
72782788ce18c2d4d760b28e0921d6ffc6431102 in Mammoth's build configuration.
The existing [JUCE framework licence notice](JUCE-LICENSE.md) is unchanged.
The [complete, unmodified upstream JUCE SPDX inventory](JUCE.spdx.json)
describes the entire JUCE source distribution, including modules not linked into
this Windows application. It is not a claim that every inventory package ships
in Mammoth. [Notice provenance and SHA-256 hashes](notice-manifest.json) identify
the packaged copies and their source material.

## Acknowledgments

This software is based in part on the work of the Independent JPEG Group.

Portions of this software use FreeType-derived code in PlutoVG and are
copyright (C) 1996-2020 David Turner, Robert Wilhelm, and Werner Lemberg.
Portions of this software are copyright (C) 1996-2020 The FreeType Project
(www.freetype.org). All rights reserved. See the exact source notices and
FreeType Project licence below.

Mammoth also uses HarfBuzz, SheenBidi, LunaSVG, PlutoVG, stb components,
Unicode data, libpng, zlib, and WinSparkle. The original copyright notices,
permissions, disclaimers, and available licence alternatives are preserved.
These acknowledgments do not choose a new application licence or change any
existing licensing arrangement.

## Notices included with this Windows package

- HarfBuzz 14.2.1: [COPYING](third-party/HarfBuzz-COPYING.txt) and
  [additional exact source notices](third-party/HarfBuzz-SOURCE-NOTICES.txt)
- SheenBidi 2.9.0: [Apache 2.0 licence](third-party/SheenBidi-LICENSE.txt) and
  [copyright notices](third-party/SheenBidi-SOURCE-NOTICES.txt)
- LunaSVG 3.5.0: [MIT licence](third-party/LunaSVG-LICENSE.txt)
- PlutoVG 1.3.2: [MIT licence](third-party/PlutoVG-LICENSE.txt)
  - FreeType-derived portions: [FTL.TXT](third-party/FTL.TXT) and
    [original copyright notices](third-party/PlutoVG-FreeType-SOURCE-NOTICES.txt)
  - stb portions: [original licence alternatives](third-party/PlutoVG-stb-NOTICES.txt)
- Unicode data: [Unicode License V3](third-party/Unicode-LICENSE.txt); the
  pinned HarfBuzz source notice retains the original 2025 Unicode attribution
- libpng 1.6.58: [licence and copyright notices](third-party/libpng-LICENSE.txt)
- IJG JPEG 10.0: [unmodified README, including legal terms](third-party/IJG-README.txt)
- zlib 1.3.2: [licence and copyright notices](third-party/zlib-LICENSE.txt)
- WinSparkle: [MIT notice](WinSparkle-LICENSE.txt) and
  [bundled Expat notice](WinSparkle-expat-LICENSE.txt)

[JUCE's dependency provenance and modifications](third-party/JUCE-DEPENDENCY-PROVENANCE.txt)
are reproduced separately. Notice texts copied from the pinned source have not
been edited; grouped source-comment extracts are explicitly labelled.

The dependency scope follows Mammoth's Windows-linked juce_audio_devices and
juce_gui_extra modules and their transitive dependencies (juce_audio_basics,
juce_events, juce_core, juce_gui_basics, juce_graphics, juce_data_structures).
ASIO is disabled by JUCE's default configuration; browser and WebView2 support
are disabled explicitly. Android Oboe, standalone JUCE audio-format codecs,
plugin SDKs, JUCE examples, and Projucer are not added to this package by this
notice correction. The complete upstream SPDX inventory remains intact.

## Restored sound and notation assets

- VSCO 2 Community Edition upright recordings: [CC0 1.0](third-party/piano-LICENSE.txt). Recorded by Sam Gossner and Simon Dalzell, sample cutting by Elan Hickler / Soundemote.
- Bravura music font, copyright Steinberg Media Technologies: [SIL Open Font License 1.1](third-party/notation-LICENSE.txt). Unmodified font, embedded in Mammoth.
